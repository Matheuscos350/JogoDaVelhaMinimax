<?php
include("cabecalho.php")
?>

<link rel="stylesheet" href="css/style.css">



<center><h1>Projeto elaborado para PROJETO EM SISTEMAS INTELIGENTES</h1></center>
<br>
<center><h3>Integrantes</h3></center>
<br>
<center><h4>Júlia Pedroso dos Santos (324101087) (Líder)</h4></center>
<center><h4>Gabriel Cruz dos Santos (324101551)</h4></center>
<center><h4>Gabriel Genaro Cardoso Ferreira (323102009) </h4></center>
<center><h4>Karine Arrivail De Oliveira (324100971)</h4></center>
<center><h4>Matheus Costa Machado (324101970) </h4></center>
<center><h4>Milton Omar Rojas Sacari (323201387)</h4></center>
<center><h4>Renan Antonio da Silva (324100796) </h4></center>
<center><h4>Ruan de Moura Rodrigues (324100862)</h4></center>

<br><br>
<center><Img id="#" src="img/uni9.png"></center>


<?php
include("rodape.php")
?>